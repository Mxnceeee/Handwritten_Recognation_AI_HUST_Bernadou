READ_ME.txt

Handwritten Digit Recognition Capstone Project

Project Overview:
This capstone project focuses on the study of handwritten digit recognition.

Code Execution:


Prepare the Workspace:

Place the following files in the same directory:

	- AI_project_main.py
	- AI_project_lib.py
	- Interactive_Interface.py
	- mnist_test.csv
	- mnist_train.csv
	- All documents related to recognition present in the .zip file.

Change the workspace directory to ensure you are in the correct location.



Code Execution Steps:

	- Open AI_project_main.py.
	- Execute the code block by block.
	- Launch the first three blocks.
	- Do not execute the fourth block, as the learning process is already completed, and necessary documents are in the .zip file.
	- Execute the fifth block to create the confusion matrix for digit 0. Modify the 89th line if you want to detect a different digit.
	- Execute the 6th, 7th, 8th, and 9th blocks to display confusion matrices for all different digits.



Demonstration Blocks:
The last three blocks are for demonstration purposes.
	- The first block detects which digits are on the first 10 lines.
	- The second block recognizes only the digit present on the i-th line. Modify the 154th line to change the line, and the block will display the image of the digit.
	- For the third block, open the .png file in the .zip with Paint. Change the digit by modifying the image. Ensure a perfectly black 	  	  	  background and write with white. Save the image and launch the code.


Interactive Interface:
	Interactive Drawing Canvas:
		-Draw digits directly using the mouse.
		-Resize and preprocess input automatically for model compatibility.

	Clear Functionality:
		-Reset the canvas to draw new digits.

	Image Upload Support:
		-Load digit images from local files for testing.
		-Automatic preprocessing to fit the model’s requirements.

	Dependencies:
		numpy
		Pillow
		opencv-python
		tkinter (comes with Python)

	Ensure the following model files are available:
		A0.npy, A1.npy, ..., A9.npy
		b0.npy, b1.npy, ..., b9.npy
		train_final0.npy, ..., train_final9.npy
