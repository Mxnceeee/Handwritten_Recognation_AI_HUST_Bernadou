import tkinter as tk
from tkinter import filedialog
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageOps
import AI_project_lib as lib  # Import the library file you provided

# Load model parameters
trainSize = 1000
listA = [np.load(f"A{i}.npy") for i in range(10)]
listb = [np.load(f"b{i}.npy") for i in range(10)]
listT = [np.load(f"train_final{i}.npy") for i in range(10)]

class DigitRecognizerApp:
    def __init__(self, master):
        self.master = master
        master.title("Handwritten Digit Recognition")

        # Drawing canvas
        self.canvas = tk.Canvas(master, width=280, height=280, bg="white")
        self.canvas.pack()
        self.canvas.bind("<B1-Motion>", self.draw)

        # Buttons
        self.predict_button = tk.Button(master, text="Predict", command=self.predict)
        self.predict_button.pack()

        self.clear_button = tk.Button(master, text="Clear", command=self.clear_canvas)
        self.clear_button.pack()

        self.load_button = tk.Button(master, text="Load Image", command=self.load_image)
        self.load_button.pack()

        # Output area
        self.output_label = tk.Label(master, text="", font=("Helvetica", 16))
        self.output_label.pack()

        # Prepare canvas for drawing
        self.image = Image.new("L", (28, 28), "black")
        self.draw_obj = ImageDraw.Draw(self.image)

    def draw(self, event):
        x, y = event.x, event.y
        self.canvas.create_oval(x-6, y-6, x+6, y+6, fill="black", width=0)
        self.draw_obj.ellipse([x//10-1, y//10-1, x//10+1, y//10+1], fill="white")

    def clear_canvas(self):
        self.canvas.delete("all")
        self.image = Image.new("L", (28, 28), "black")
        self.draw_obj = ImageDraw.Draw(self.image)
        self.output_label.config(text="")

    def predict(self):
        # Resize and convert the image
        img = np.asarray(self.image).flatten() * 0.99 / 255 + 0.01
        result = lib.f_pred(trainSize, img, listA, listb, listT)
        self.output_label.config(text=f"Predicted Digit: {result}")

    def load_image(self):
        filepath = filedialog.askopenfilename()
        if filepath:
            img = Image.open(filepath).convert("L")
            img_resized = ImageOps.fit(img, (28, 28), method=Image.Resampling.LANCZOS)
            img_normalized = np.asarray(img_resized).flatten() * 0.99 / 255 + 0.01
            result = lib.f_pred(trainSize, img_normalized, listA, listb, listT)
            self.output_label.config(text=f"Predicted Digit: {result}")

root = tk.Tk()
app = DigitRecognizerApp(root)
root.mainloop()
